import { stationsFor } from "@/lib/bike-service";
import { isCityId, loadAtlas, loadTimetable } from "@/lib/atlas/store";
import { allowRateLimit, isPlace, parseClock, readJsonBody, requestRateLimitKey } from "@/lib/http";
import { planTrip } from "@/lib/planner";
import { activeServiceIndexes } from "@/lib/services";
import { minutesOfDay, montrealNow } from "@/lib/time";
import { planTrajectories } from "@/lib/trajectory";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!allowRateLimit(requestRateLimitKey(request, "plan"), 60, 60_000)) {
    return Response.json({ error: "Trop de requêtes." }, { status: 429 });
  }
  const parsed = await readJsonBody<{
    city?: unknown;
    from?: unknown;
    to?: unknown;
    at?: unknown;
  }>(request);
  if (!parsed.ok || !parsed.value || typeof parsed.value !== "object") {
    return Response.json({ error: "Corps JSON invalide." }, { status: 400 });
  }
  const body = parsed.value;
  if (typeof body.city !== "string" || !isCityId(body.city) || !isPlace(body.from) || !isPlace(body.to)) {
    return Response.json({ error: "Requête incomplète." }, { status: 400 });
  }
  const at = body.at ? parseClock(body.at) : montrealNow();
  if (!at) {
    return Response.json({ error: "Horloge invalide." }, { status: 400 });
  }
  const [atlas, timetable, bikes] = await Promise.all([
    loadAtlas(body.city),
    loadTimetable(body.city),
    stationsFor(body.city).catch(() => []),
  ]);
  const now = minutesOfDay(at);
  const active = activeServiceIndexes(atlas, at);
  const itineraries = planTrip(atlas, timetable, body.from, body.to, now, active, bikes);
  const options = planTrajectories(atlas, timetable, body.from, body.to, now, active, bikes);
  return Response.json({
    city: body.city,
    at: at.toISOString(),
    itineraries,
    options: options.map((row) => ({
      mix: row.mix,
      minutes: row.minutes,
      walkMeters: row.walkMeters,
      itinerary: row.itinerary,
    })),
  });
}
