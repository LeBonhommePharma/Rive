"use client";

import { FormEvent, useDeferredValue, useEffect, useMemo, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import {
  ArrowRight,
  ArrowsDownUp,
  CaretDown,
  MapTrifold,
  Clock,
  Bus,
  Crosshair,
  MagnifyingGlass,
  MapPin,
  PersonSimpleWalk,
  Subway,
  X,
} from "@phosphor-icons/react";
const MapView = dynamic(
  () => import("@/components/map-view").then((mod) => mod.MapView),
  { ssr: false },
);
import type {
  Atlas,
  AtlasRoute,
  AtlasStop,
  CityId,
  Itinerary,
  Place,
} from "@/lib/atlas/types";
import type { Poi } from "@/lib/poi";
import { understandQuery, type CityHint } from "@/lib/assist";
import { t, type MessageId } from "@/lib/i18n";
import { chipsForCities, placeFromStop, searchAtlas, type CityVisit } from "@/lib/search";
import { resolveSearchAction } from "@/lib/search-submit";
import { formatClock, formatRelative } from "@/lib/time";
import { fetchJson, readJsonResponse } from "@/lib/client-http";

type Field = "from" | "to";
type Departure = {
  routeId: string;
  shortName: string;
  color: string;
  textColor: string;
  headsign: string;
  type: number;
  agencyId?: string;
  depart: number;
  wait: number;
  times?: number[];
};

const FALLBACK_CITIES: Array<{ id: CityId; label: string; hints: [string, string] }> = [
  { id: "quebec", label: "Québec", hints: ["Place D'Youville", "Terminus de la Traverse"] },
  { id: "montreal", label: "Montréal", hints: ["Berri-UQAM", "Terminus Montmorency"] },
  { id: "sherbrooke", label: "Sherbrooke", hints: ["Université de Sherbrooke", "Station du Cégep"] },
  { id: "trois-rivieres", label: "Trois-Rivières", hints: ["Terminus Centre-ville", "Terminus UQTR"] },
];

function modeIcon(type: number, className: string) {
  if (type === 1) return <Subway className={className} weight="regular" />;
  return <Bus className={className} weight="regular" />;
}

export function RiveApp() {
  const reduce = useReducedMotion();
  const [locale] = useState("fr");
  const [cities, setCities] = useState(FALLBACK_CITIES);
  const [city, setCity] = useState<CityId>("quebec");
  const [visit, setVisit] = useState<CityVisit | null>(null);
  const [atlas, setAtlas] = useState<Atlas | null>(null);
  const [pois, setPois] = useState<Poi[]>([]);
  const [loadError, setLoadError] = useState("");
  const [fromQuery, setFromQuery] = useState("");
  const [toQuery, setToQuery] = useState("");
  const [from, setFrom] = useState<Place | null>(null);
  const [to, setTo] = useState<Place | null>(null);
  const [activeField, setActiveField] = useState<Field>("to");
  const [itineraries, setItineraries] = useState<Itinerary[]>([]);
  const [chosen, setChosen] = useState<string | null>(null);
  const [planning, setPlanning] = useState(false);
  const [planError, setPlanError] = useState("");
  const [selectedStop, setSelectedStop] = useState<AtlasStop | null>(null);
  const [departures, setDepartures] = useState<Departure[]>([]);
  const [selectedRouteId, setSelectedRouteId] = useState<string | null>(null);
  const [departuresBusy, setDeparturesBusy] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [locationBusy, setLocationBusy] = useState(false);
  const [locationError, setLocationError] = useState("");
  const [departureError, setDepartureError] = useState("");
  const locationRun = useRef(0);
  const fromInput = useRef<HTMLInputElement>(null);
  const toInput = useRef<HTMLInputElement>(null);
  const departuresRun = useRef<AbortController | null>(null);
  const planRun = useRef(0);

  const tr = (id: MessageId) => t(id, locale);
  const chips = useMemo(
    () => chipsForCities(cities.map((item) => ({ city: item.id, name: item.label }))),
    [cities],
  );

  useEffect(() => {
    fetchJson<{ cities?: Array<{ city?: unknown; name?: unknown }> }>("/data/index.json", 2 * 1024 * 1024)
      .then((data: { cities?: Array<{ city?: unknown; name?: unknown }> } | null) => {
        const loaded = (data?.cities || [])
          .filter(
            (item): item is { city: string; name: string } =>
              typeof item.city === "string" &&
              item.city.length <= 64 &&
              /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(item.city) &&
              typeof item.name === "string",
          )
          .map((item) => ({
            id: item.city,
            label: item.name,
            hints: FALLBACK_CITIES.find((entry) => entry.id === item.city)?.hints || [item.name, "Arrêts près d'ici"] as [string, string],
          }));
        if (loaded.length) setCities(loaded);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    let alive = true;
    async function load() {
      if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(city) || city.length > 64) throw new Error("Ville invalide.");
      const data = await fetchJson<Atlas>(`/data/${encodeURIComponent(city)}/atlas.json`);
      let places: Poi[] = [];
      for (const path of [`/data/${encodeURIComponent(city)}/pois.json`, "/data/pois.json"]) {
        let parsed: { places?: Poi[] };
        try {
          parsed = await fetchJson<{ places?: Poi[] }>(path, 2 * 1024 * 1024);
        } catch {
          continue;
        }
        places = (parsed.places || []).filter((place) => !place.city || place.city === city);
        break;
      }
      if (alive) {
        setAtlas(data);
        setPois(places);
      }
    }
    load().catch((err: Error) => {
      if (alive) setLoadError(err.message);
    });
    return () => {
      alive = false;
    };
  }, [city]);

  const typed = activeField === "from" ? fromQuery : toQuery;
  const deferredQuery = useDeferredValue(typed);
  const hits = useMemo(() => {
    if (!atlas) return [];
    return searchAtlas(atlas, deferredQuery, 7, undefined, { pois });
  }, [atlas, deferredQuery, pois]);

  const selectedRoute = useMemo(
    () => atlas?.routes.find((r) => r.id === selectedRouteId) ?? null,
    [atlas, selectedRouteId],
  );
  const activeItinerary = useMemo(
    () => itineraries.find((item) => item.id === chosen) ?? itineraries[0] ?? null,
    [itineraries, chosen],
  );

  function pickStopAs(field: Field, stop: AtlasStop) {
    setSearchOpen(false);
    const place: Place = {
      label: stop.name,
      lon: stop.lon,
      lat: stop.lat,
      stopId: stop.id,
    };
    if (field === "from") {
      setFrom(place);
      setFromQuery(stop.name);
    } else {
      setTo(place);
      setToQuery(stop.name);
    }
  }

  async function openStop(stop: AtlasStop) {
    setCollapsed(false);
    setSearchOpen(false);
    setDepartureError("");
    setSelectedStop(stop);
    setSelectedRouteId(null);
    pickStopAs(activeField, stop);
    departuresRun.current?.abort();
    const run = new AbortController();
    departuresRun.current = run;
    setDepartures([]);
    setDeparturesBusy(true);
    try {
      const res = await fetch(
        `/api/departures?city=${encodeURIComponent(city)}&stop=${encodeURIComponent(stop.id)}`,
        { signal: run.signal },
      );
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await readJsonResponse<{ departures: Departure[] }>(res, 512 * 1024);
      if (departuresRun.current !== run) return;
      setDepartures(data.departures);
    } catch {
      if (departuresRun.current === run && !run.signal.aborted) {
        setDepartures([]);
        setDepartureError("Les horaires sont indisponibles pour le moment.");
      }
    } finally {
      if (departuresRun.current === run) setDeparturesBusy(false);
    }
  }

  function pickPoiAs(field: Field, poi: Poi) {
    setSearchOpen(false);
    setSelectedStop(null);
    const place: Place = { label: poi.name, lon: poi.lon, lat: poi.lat };
    if (field === "from") {
      setFrom(place);
      setFromQuery(poi.name);
    } else {
      setTo(place);
      setToQuery(poi.name);
    }
    const nextFrom = field === "from" ? place : from;
    const nextTo = field === "to" ? place : to;
    if (nextFrom && nextTo) void plan(nextFrom, nextTo);
  }

  async function plan(nextFrom = from, nextTo = to) {
    if (!nextFrom || !nextTo) return;
    setSearchOpen(false);
    setSelectedStop(null);
    setCollapsed(false);
    setItineraries([]);
    const run = ++planRun.current;
    setPlanning(true);
    setPlanError("");
    try {
      const res = await fetch("/api/plan", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ city, from: nextFrom, to: nextTo }),
      });
      const data = await readJsonResponse<{ itineraries?: Itinerary[]; error?: string }>(res, 4 * 1024 * 1024);
      if (planRun.current !== run) return;
      if (!res.ok) throw new Error(data.error || "Planification impossible.");
      const list = data.itineraries ?? [];
      setItineraries(list);
      setChosen(list[0]?.id ?? null);
      if (list.length === 0) {
        setPlanError("Aucun trajet trouvé sur les horaires du jour.");
      }
    } catch (err) {
      if (planRun.current !== run) return;
      setPlanError(err instanceof Error ? err.message : "Planification impossible.");
    } finally {
      if (planRun.current === run) setPlanning(false);
    }
  }

  async function onSearch(event: FormEvent) {
    event.preventDefault();
    const raw = typed.trim();
    const action = resolveSearchAction({ from, to, query: raw });
    if (action === "plan" && from && to) {
      void plan();
      return;
    }
    if (action === "schedule" && atlas && raw) {
       const intent = await understandQuery(raw, cities as CityHint[]);
      if (intent.city && intent.city !== city) {
         setPlanError("Choisis d’abord cette ville dans la barre du haut, puis relance la recherche.");
         return;
       }
       const hit = searchAtlas(atlas, intent.query, 1, undefined, { pois })[0];
       if (hit?.kind === "stop") void openStop(hit.stop);
       else if (hit?.kind === "poi") pickPoiAs(activeField, hit.poi);
       else if (hit?.kind === "route") { setSelectedRouteId(hit.route.id); setSelectedStop(null); setSearchOpen(false); }
       else setPlanError("Aucun résultat. Essaie un nom d’arrêt, une adresse connue ou un numéro de ligne.");
    }
  }

  function locate() {
    setLocationError("");
    if (!navigator.geolocation) {
      setLocationError("La position n’est pas disponible. Saisis ton point de départ.");
      return;
    }
    const run = ++locationRun.current;
    setLocationBusy(true);
    navigator.geolocation.getCurrentPosition((pos) => {
      if (run !== locationRun.current) return;
      const place: Place = { label: tr("myPosition"), lon: pos.coords.longitude, lat: pos.coords.latitude };
      setFrom(place);
      setFromQuery(place.label);
      setActiveField("to");
      setLocationBusy(false);
      toInput.current?.focus();
    }, (error) => {
      if (run !== locationRun.current) return;
      setLocationBusy(false);
      setLocationError(error.code === 1
        ? "Position refusée. Tu peux saisir ton point de départ."
        : "Position introuvable. Réessaie ou saisis ton point de départ.");
    }, { timeout: 10000, maximumAge: 60000 });
  }

  function invalidateTrip() {
    ++planRun.current;
    setPlanning(false);
    setItineraries([]);
    setChosen(null);
    setPlanError("");
    setSelectedStop(null);
    setSelectedRouteId(null);
  }

  function swapPlaces() {
    invalidateTrip();
    setFrom(to);
    setTo(from);
    setFromQuery(toQuery);
    setToQuery(fromQuery);
    setSearchOpen(false);
    if (from && to) void plan(to, from);
  }

  async function applyHint(name: string, field: Field) {
    if (!atlas) return;
    const hit = searchAtlas(atlas, name, 1)[0];
    if (hit?.kind === "stop") {
      pickStopAs(field, hit.stop);
      if (field === "from" && to) void plan({
        label: hit.stop.name,
        lon: hit.stop.lon,
        lat: hit.stop.lat,
        stopId: hit.stop.id,
      }, to);
      if (field === "to" && from) {
        void plan(from, {
          label: hit.stop.name,
          lon: hit.stop.lon,
          lat: hit.stop.lat,
          stopId: hit.stop.id,
        });
      }
    } else {
      if (field === "from") setFromQuery(name);
      else setToQuery(name);
    }
  }

  return (
    <main className="rive-app relative h-[100dvh] overflow-hidden bg-paper text-ink">
      <a href="#journey-destination" className="skip-link">Aller à la recherche</a>
      <MapView
        city={city}
        atlas={atlas}
        focus={visit}
        selectedStop={selectedStop}
        selectedRouteId={selectedRouteId}
        itinerary={activeItinerary}
        onStop={(stop) => void openStop(stop)}
        onRoute={(id) => {
          setSelectedRouteId(id);
          setSelectedStop(null);
        }}
      />

      <div className="pointer-events-none absolute inset-0 z-[2]">
        <header className="rive-brand"><span className="brand-symbol"><Bus size={24} weight="bold" /></span><span>rive<span className="brand-dot">.</span></span><p>La ville, à ta portée.</p></header>
        <div className="city-navigation">
          <div className="glass city-strip" role="group" aria-label="Choisir une ville">
            {chips.map((item) => {
              const on = item.kind === "visit" ? visit?.id === item.id : item.city === city && !visit;
              return (
                <button
                  key={item.id}
                  aria-pressed={on}
                  type="button"
                  onClick={() => {
                    if (on) return;
                    ++planRun.current;
                    ++locationRun.current;
                    departuresRun.current?.abort();
                    setPlanning(false);
                    setLocationBusy(false);
                    setLocationError("");
                    setSearchOpen(false);
                    setDepartureError("");
                    if (item.city !== city) setAtlas(null);
                    setCity(item.city);
                    setVisit(item.visit || null);
                    setLoadError("");
                    setItineraries([]);
                    setChosen(null);
                    setSelectedStop(null);
                    setSelectedRouteId(null);
                    setFrom(null);
                    setTo(null);
                    setFromQuery("");
                    setToQuery("");
                    setDepartures([]);
                    setPlanError("");
                  }}
                  className={`shrink-0 cursor-pointer rounded-[10px] px-3 py-2 text-[13px] font-semibold tracking-tight min-h-11 transition-colors duration-200 ease-[cubic-bezier(0.16,1,0.3,1)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sodium ${
                    on
                      ? "bg-sodium text-[#f0fdfa]"
                      : "text-muted hover:bg-black/5 hover:text-ink"
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>

        <aside className={`journey-panel glass ${collapsed ? "is-collapsed" : ""}`} aria-label="Rechercher et préparer un trajet">
          <button type="button" className="panel-toggle" onClick={() => setCollapsed(!collapsed)} aria-expanded={!collapsed} aria-controls="journey-content">
            <span><MapTrifold size={18} />{collapsed ? "Préparer mon trajet" : "Voir la carte"}</span><CaretDown size={18} />
          </button>
          <div id="journey-content" className="journey-content" hidden={collapsed}>
        <form onSubmit={onSearch} onKeyDown={(event) => { if (event.key === "Escape") setSearchOpen(false); }}>
          <div className="search-section">
            <div className="flex items-center justify-between px-2 pb-2">
              <div><p className="eyebrow">ON Y VA ?</p><h1>Où vas-tu ?</h1></div>
              <button
                type="button"
                onClick={locate}
                disabled={locationBusy}
                title="Utiliser ma position comme départ"
                className="flex h-11 w-11 items-center justify-center rounded-[10px] bg-well text-ink/70 transition-colors duration-200 ease-[cubic-bezier(0.16,1,0.3,1)] hover:bg-well-hi hover:text-ink"
                aria-label="Utiliser ma position"
              >
                <Crosshair size={21} className={locationBusy ? "animate-pulse" : ""} />
              </button>
            </div>
            <p className="search-intro">Un trajet à préparer. Un arrêt à consulter.</p>
            <label className="journey-field mb-2 flex items-center gap-2 rounded-[10px] border border-hairline bg-well px-3 py-2.5 transition-colors focus-within:border-sodium">
              <PersonSimpleWalk size={16} className="text-sodium/80" />
              <span className="sr-only">Départ</span>
              <input
                ref={fromInput}
                autoComplete="off"
                maxLength={512}
                value={fromQuery}
                onChange={(e) => {
                  invalidateTrip();
                  setSearchOpen(true);
                  setFromQuery(e.target.value);
                  setFrom(null);
                  setActiveField("from");
                }}
                onFocus={() => { setActiveField("from"); setSearchOpen(true); }}
                onKeyDown={(event) => { if (event.key === "ArrowDown") { event.preventDefault(); document.querySelector<HTMLButtonElement>(".search-results button")?.focus(); } }}
                placeholder="Point de départ"
                className="w-full bg-transparent text-sm text-ink outline-none placeholder:text-ink/45"
              />
            </label>
            <label className="journey-field flex items-center gap-2 rounded-[10px] border border-hairline bg-well px-3 py-2.5 transition-colors focus-within:border-sodium">
              <MapPin size={16} className="text-sodium" />
              <span className="sr-only">Destination</span>
              <input
                id="journey-destination"
                ref={toInput}
                autoComplete="off"
                maxLength={512}
                value={toQuery}
                onChange={(e) => {
                  invalidateTrip();
                  setSearchOpen(true);
                  setToQuery(e.target.value);
                  setTo(null);
                  setActiveField("to");
                }}
                onFocus={() => { setActiveField("to"); setSearchOpen(true); }}
                onKeyDown={(event) => { if (event.key === "ArrowDown") { event.preventDefault(); document.querySelector<HTMLButtonElement>(".search-results button")?.focus(); } }}
                placeholder="Destination, arrêt ou ligne"
                className="w-full bg-transparent text-sm text-ink outline-none placeholder:text-ink/45"
              />
              <button
                type="submit"
                disabled={!typed.trim() || planning || !atlas}
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-[10px] bg-sodium text-[#f0fdfa] transition-opacity disabled:opacity-30"
                aria-label={from && to ? tr("searchTrip") : "Rechercher un arrêt ou une ligne"}
              >
                <MagnifyingGlass size={15} weight="bold" />
              </button>
            </label>

            <div className="search-actions">
              <span><Clock size={15} /> Horaires du jour</span>
              <button type="button" onClick={swapPlaces} disabled={!fromQuery && !toQuery}><ArrowsDownUp size={16} /> Inverser</button>
            </div>
            {locationBusy && <p className="feedback" role="status">Recherche de ta position…</p>}
            {locationError && <p className="feedback" role="status">{locationError}</p>}
            {searchOpen && typed.trim() && deferredQuery === typed && hits.length === 0 && atlas && (
              <p className="feedback" role="status">Aucun résultat dans cette ville. Essaie un autre arrêt ou une ligne.</p>
            )}
            {searchOpen && typed.trim() && hits.length > 0 && (
              <ul className="search-results mt-2 divide-y divide-hairline" aria-label="Résultats de recherche">
                {hits.map((hit) =>
                  hit.kind === "stop" ? (
                    <li key={`s-${hit.stop.id}`}>
                      <button
                        type="button"
                        onClick={() => {
                          const place = placeFromStop(hit.stop);
                          pickStopAs(activeField, hit.stop);
                          const nextFrom = activeField === "from" ? place : from;
                          const nextTo = activeField === "to" ? place : to;
                          if (nextFrom && nextTo) void plan(nextFrom, nextTo);
                          else void openStop(hit.stop);
                        }}
                        className="flex w-full items-center gap-3 px-2 py-2.5 text-left"
                      >
                        <MapPin size={16} className="text-ink/50" />
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm">{hit.stop.name}</span>
                          {hit.stop.agencyId && (
                            <span className="block text-[11px] text-ink/45">{hit.stop.agencyId}</span>
                          )}
                        </span>
                      </button>
                    </li>
                  ) : hit.kind === "poi" ? (
                    <li key={`p-${hit.poi.id}`}>
                      <button
                        type="button"
                        onClick={() => pickPoiAs(activeField, hit.poi)}
                        className="flex w-full items-center gap-3 px-2 py-2.5 text-left"
                      >
                        <MapPin size={16} className="text-[#d97706]" />
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm">{hit.poi.name}</span>
                          <span className="block text-[11px] text-ink/45">
                            {hit.poi.category || "Lieu"}
                          </span>
                        </span>
                      </button>
                    </li>
                  ) : (
                    <li key={`r-${hit.route.id}`}>
                      <button
                        type="button"
                        onClick={() => { setSelectedRouteId(hit.route.id); setSelectedStop(null); setSearchOpen(false); }}
                        className="flex w-full items-center gap-3 px-2 py-2.5 text-left"
                      >
                        <RouteBadge route={hit.route} />
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm text-ink/80">
                            {hit.route.longName || hit.route.shortName}
                          </span>
                          {hit.route.agencyId && (
                            <span className="block text-[11px] text-ink/45">{hit.route.agencyId}</span>
                          )}
                        </span>
                      </button>
                    </li>
                  ),
                )}
              </ul>
            )}

            {!fromQuery && !toQuery && (
              <div className="mt-3 flex flex-wrap gap-2 px-1">
                {(cities.find((item) => item.id === city)?.hints || ["Ici", "Arrêts près d'ici"]).map((hint, index) => (
                  <button
                    key={hint}
                    type="button"
                    onClick={() => void applyHint(hint, index === 0 ? "from" : "to")}
                    className="min-h-9 rounded-full bg-well px-3 py-1 text-xs text-ink/75 transition-colors hover:bg-well-hi hover:text-ink"
                  >
                    {hint}
                  </button>
                ))}
              </div>
            )}
          </div>
        </form>

        <div className="journey-results" aria-live="polite" aria-busy={planning || departuresBusy}>
          {!selectedStop && !selectedRoute && !planning && !itineraries.length && !planError && (
            <section className="explore-section">
              <div className="section-heading"><h2>Explore le réseau</h2><span>{visit?.label || cities.find((item) => item.id === city)?.label}</span></div>
              <p>Choisis une ligne pour voir son parcours sur la carte.</p>
              <div className="route-grid">
                {atlas?.routes.filter((route) => route.type === 1 || /^80[0-7]$/.test(route.shortName)).slice(0, 6).map((route) => (
                  <button type="button" key={route.id} onClick={() => { setSelectedRouteId(route.id); setSearchOpen(false); }}>
                    <RouteBadge route={route} /><span>{route.longName || route.shortName}</span><ArrowRight size={16} />
                  </button>
                ))}
              </div>
              <a className="atlas-link" href="/Transit/index.html">Ouvrir l’atlas complet <ArrowRight size={17} /></a>
            </section>
          )}
          <AnimatePresence mode="wait">
            {selectedStop && (
              <motion.section
                key={selectedStop.id}
                initial={reduce ? false : { opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={reduce ? undefined : { opacity: 0, y: 16 }}
                transition={{ duration: 0.45, ease: [0.32, 0.72, 0, 1] }}
                className="departure-section p-5"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h2 className="text-xl font-medium tracking-tight">{selectedStop.name}</h2>
                    <p className="mt-1 text-sm text-muted">{tr("remoteHint")}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedStop(null)}
                    className="flex h-11 w-11 items-center justify-center rounded-[10px] bg-well text-ink/70 transition-colors hover:bg-well-hi hover:text-ink"
                    aria-label={tr("close")}
                  >
                    <X size={14} />
                  </button>
                </div>
                <ul className="mt-4 space-y-3">
                  {departuresBusy && <li className="text-sm text-muted">Lecture des horaires…</li>}
                  {departureError && <li className="feedback">{departureError}<button type="button" className="retry-button" onClick={() => void openStop(selectedStop)}>Réessayer</button></li>}
                  {!departuresBusy && !departureError && departures.length === 0 && (
                    <li className="text-sm text-muted">{tr("noPassages")}</li>
                  )}
                  {departures.map((row) => (
                    <li key={`${row.routeId}-${row.headsign}`} className="flex items-center gap-3">
                      <span
                        className="inline-flex min-w-12 items-center justify-center rounded-full px-2 py-1 text-xs font-semibold"
                        style={{ background: row.color, color: row.textColor }}
                      >
                        {row.shortName}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm">{row.headsign}</p>
                        <p className="font-mono text-[11px] text-ink/45">
                          {(row.times && row.times.length > 0 ? row.times : [row.depart])
                            .slice(0, 5)
                            .map((t) => formatClock(t))
                            .join("  ")}
                          {row.agencyId ? `  ${row.agencyId}` : ""}
                        </p>
                      </div>
                      <span
                        className="departure-countdown"
                      >
                        {row.wait > 90 ? formatClock(row.depart) : formatRelative(row.wait)}
                      </span>
                    </li>
                  ))}
                </ul>
              </motion.section>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {(planning || itineraries.length > 0 || planError) && (
              <motion.section
                initial={reduce ? false : { opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                exit={reduce ? undefined : { opacity: 0, y: 18 }}
                transition={{ duration: 0.5, ease: [0.32, 0.72, 0, 1] }}
                className="detail-section p-5"
              >
                {planning && (
                  <p className="text-sm text-muted">Lecture des horaires…</p>
                )}
                {planError && <p className="text-sm text-ink">{planError}</p>}
                {itineraries.map((item) => {
                  const on = item.id === (chosen ?? itineraries[0]?.id);
                  const transit = item.legs.find((leg) => leg.kind === "transit");
                  return (
                    <button
                      key={item.id}
                      aria-pressed={on}
                      type="button"
                      onClick={() => setChosen(item.id)}
                      className={`mb-3 w-full rounded-[10px] p-4 text-left transition-colors last:mb-0 ${
                        on ? "bg-well ring-1 ring-sodium/40" : "bg-transparent hover:bg-well"
                      }`}
                    >
                      <div className="flex items-end justify-between">
                        <p className="text-3xl font-medium tracking-tight">
                          {item.minutes} min
                        </p>
                        <p className="text-xs text-ink/55">
                          {item.transfers === 0
                            ? tr("direct")
                            : `${item.transfers} ${tr("transfer")}`}
                        </p>
                      </div>
                      <div className="mt-3 flex flex-wrap items-center gap-2 text-sm">
                        {item.legs.map((leg, i) =>
                          leg.kind === "walk" ? (
                            <span key={i} className="inline-flex items-center gap-1 text-ink/75">
                              <PersonSimpleWalk size={14} />
                              {leg.minutes} min
                            </span>
                          ) : leg.kind === "bike" ? (
                            <span key={i} className="inline-flex items-center gap-1 text-ink/75">
                              {leg.system === "avelo" ? "àVélo" : "BIXI"} {leg.minutes} min
                            </span>
                          ) : leg.kind === "road" ? (
                            <span key={i} className="inline-flex items-center gap-1 text-ink/75">
                              Auto {leg.minutes} min
                            </span>
                          ) : (
                            <span key={i} className="inline-flex items-center gap-2">
                              {i > 0 && <ArrowRight size={12} className="text-ink/45" />}
                              <span
                                className="rounded-full px-2 py-0.5 text-xs font-semibold"
                                style={{ background: leg.color, color: leg.textColor }}
                              >
                                {leg.shortName}
                              </span>
                              <span className="text-ink/75">
                                {leg.headsign}
                                {leg.agencyId ? ` · ${leg.agencyId}` : ""}
                              </span>
                            </span>
                          ),
                        )}
                      </div>
                      {transit && on && (
                        <p className="mt-3 font-mono text-[11px] text-ink/45">
                          {formatClock(transit.depart)} → {formatClock(transit.arrive)}
                          {atlas ? ` · ${atlas.meta.agencyId}` : ""}
                        </p>
                      )}
                    </button>
                  );
                })}
              </motion.section>
            )}
          </AnimatePresence>

          {selectedRoute && !selectedStop && itineraries.length === 0 && (
            <section className="detail-section p-5">
              <div className="section-heading"><h2>Parcours de la ligne</h2><button type="button" className="close-button" aria-label="Fermer le parcours" onClick={() => setSelectedRouteId(null)}><X size={18} /></button></div>
              <div className="flex items-center gap-3">
                <RouteBadge route={selectedRoute} />
                <div>
                  <h2 className="text-lg font-medium">{selectedRoute.shortName}</h2>
                  <p className="text-sm text-muted">{selectedRoute.longName}</p>
                </div>
              </div>
            </section>
          )}
        </div>

        <footer className="journey-footer"><span>Gratuit. Sans abonnement.</span><span>Horaires officiels · Rive</span></footer>
          </div>
        </aside>
        <div className="map-caption"><MapPin size={15} /><span>{visit?.label || cities.find((item) => item.id === city)?.label}</span><span>Bus · Métro · Marche</span></div>

      </div>

      {!atlas && !loadError && (
        <div className="loading-notice glass" role="status">
          <p className="text-sm text-muted">{tr("loading")}</p>
        </div>
      )}
      {loadError && (
        <div className="loading-notice glass" role="alert">
          <p className="max-w-sm text-sm text-ink">Impossible de charger ce réseau. {loadError} Choisis une autre ville ou <button className="retry-button" onClick={() => window.location.reload()}>réessaie</button>.</p>
        </div>
      )}
    </main>
  );
}

function RouteBadge({ route }: { route: AtlasRoute }) {
  return (
    <span
      className="inline-flex min-w-12 items-center justify-center gap-1 rounded-full px-2 py-1 text-xs font-semibold"
      style={{ background: route.color, color: route.textColor }}
    >
      {modeIcon(route.type, "h-3 w-3")}
      {route.shortName}
    </span>
  );
}
